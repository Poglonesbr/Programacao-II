# Ambiente Python para TensorFlow

Este diretório contém um ambiente virtual e instruções para rodar o script de análise de sentimentos.

Passos rápidos:

1. Entrar na pasta do projeto:

```bash
cd "/workspaces/Programacao-II/Rede Neural"
```

2. Criar o virtualenv (já pode estar criado por este repositório):

```bash
python3 -m venv venv-tf
```

3. Ativar o virtualenv:

```bash
source venv-tf/bin/activate
```

4. Atualizar pip e instalar dependências:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

5. Executar o script de análise (por exemplo):

```bash
python "rede neural/3_tf_analise_sentimento.py"
```

Observações:
- A instalação do `tensorflow` pode demorar e usar bastante espaço em disco.
- Em alguns ambientes pode ser necessário instalar pacotes do sistema (build-essential, libffi, etc.).
- Se você estiver em um ambiente com GPU, considere instalar a versão adequada (`tensorflow` com suporte GPU) e drivers correspondentes.

Se quiser, eu crio o virtualenv e instalo agora no container. Diga se quer que eu prossiga com a instalação automática.
