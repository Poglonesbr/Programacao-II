# 🚀 Como Executar o Sistema de Análise de Sentimentos

## Passo a Passo

### 1️⃣ Treinar o modelo e iniciar a API Python (primeira vez)

Abra um terminal e execute:

```bash
cd "/workspaces/Programacao-II/Rede Neural"
source .venv/bin/activate
cd "rede neural"
python 3_tf_analise_sentimento.py
```

✅ Isso irá:
- Treinar a rede neural (~2-5 minutos)
- Salvar o modelo treinado
- **Iniciar automaticamente a API Flask na porta 5000**

⚠️ **Mantenha este terminal aberto** - a API precisa estar rodando!

### 2️⃣ Iniciar o servidor web (frontend)

Em **outro terminal**, execute:

```bash
cd "/workspaces/Programacao-II/Rede Neural"
npm start
```

✅ Isso iniciará o servidor Node.js na porta 3000

### 3️⃣ Acessar o sistema

Abra seu navegador em: **http://localhost:3000**

- Digite uma frase no campo de texto
- Clique em "Analisar Sentimento"
- Veja o resultado: Positivo ✅ ou Negativo ❌

---

## 📝 Próximas execuções (quando o modelo já existe)

Se você já treinou o modelo e só quer rodar a API:

**Terminal 1 (API Python):**
```bash
cd "/workspaces/Programacao-II/Rede Neural"
source .venv/bin/activate
cd "rede neural"
python api_server.py
```

**Terminal 2 (Frontend):**
```bash
cd "/workspaces/Programacao-II/Rede Neural"
npm start
```

---

## 🔧 Solução de Problemas

### "Erro ao conectar com API"
- Verifique se o terminal com a API Python está rodando
- A API deve estar em `http://localhost:5000`

### "Modelo não encontrado"
- Execute o treinamento primeiro (passo 1)

### Retreinar o modelo
```bash
cd "/workspaces/Programacao-II/Rede Neural/rede neural"
rm modelo_sentimentos.h5 tokenizer.pickle config.pickle
python 3_tf_analise_sentimento.py
```
