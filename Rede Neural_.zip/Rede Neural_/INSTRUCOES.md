# Sistema de Análise de Sentimentos

Sistema completo com frontend (HTML/JS) e backend Python (TensorFlow + Flask).

## Arquitetura

- **Frontend**: HTML + JavaScript (servidor Node.js na porta 3000)
- **Backend**: Python Flask + TensorFlow (porta 5000)
- **Modelo**: Rede neural treinada com análise de sentimentos

## Como Executar

### 1. Primeira execução - Treinar o modelo

O modelo precisa ser treinado **uma vez** antes de usar a API:

```bash
cd "/workspaces/Programacao-II/Rede Neural"
source .venv/bin/activate
cd "rede neural"
python 3_tf_analise_sentimento.py
```

Isso irá:
- Carregar o dataset `reviews.csv`
- Treinar a rede neural (30 épocas, ~2-5 minutos)
- Salvar os arquivos: `modelo_sentimentos.h5`, `tokenizer.pickle`, `config.pickle`
- **Iniciar automaticamente a API Flask** na porta 5000

### 2. Iniciar o servidor frontend (Node.js)

Em **outro terminal**, execute:

```bash
cd "/workspaces/Programacao-II/Rede Neural"
npm start
```

Isso iniciará o servidor Node.js na porta 3000.

### 3. Acessar a aplicação

Abra o navegador em: **http://localhost:3000**

- Digite uma frase no campo de texto
- Clique em "Analisar Sentimento"
- O resultado (Positivo/Negativo) será exibido com probabilidades

## Estrutura de Arquivos

```
Rede Neural/
├── rede neural/
│   ├── 3_tf_analise_sentimento.py  # Script principal (treina + API)
│   ├── modelo_sentimentos.h5       # Modelo treinado (gerado)
│   ├── tokenizer.pickle            # Tokenizer (gerado)
│   └── config.pickle               # Configurações (gerado)
├── public/
│   ├── index.html                  # Interface do usuário
│   ├── index.js                    # Lógica frontend
│   └── index.css                   # Estilos
├── server.js                       # Servidor Node.js
├── requirements.txt                # Dependências Python
├── package.json                    # Dependências Node.js
└── reviews.csv                     # Dataset para treinamento
```

## API Endpoints

### POST /analisar
Analisa o sentimento de uma frase.

**Request:**
```json
{
  "frase": "Este produto é excelente!"
}
```

**Response:**
```json
{
  "resultados": [
    {
      "frase": "Este produto é excelente!",
      "sentimento": "Positivo",
      "probabilidade_positivo": 0.95,
      "probabilidade_negativo": 0.05
    }
  ]
}
```

### GET /health
Verifica se a API está funcionando.

**Response:**
```json
{
  "status": "OK",
  "modelo": "carregado"
}
```

## Apenas executar a API (sem retreinar)

Se o modelo já foi treinado e você quer **apenas iniciar a API**:

```bash
cd "/workspaces/Programacao-II/Rede Neural"
source .venv/bin/activate
cd "rede neural"
python api_server.py
```

## Solução de Problemas

### Erro: "Modelo não encontrado"
Execute o treinamento primeiro (passo 1).

### Erro: "Não foi possível conectar à API"
Verifique se o servidor Python está rodando na porta 5000.

### Erro de CORS
Certifique-se de que `flask-cors` está instalado:
```bash
source .venv/bin/activate
pip install flask-cors
```

### Retreinar o modelo
Delete os arquivos gerados e execute novamente:
```bash
cd "/workspaces/Programacao-II/Rede Neural/rede neural"
rm modelo_sentimentos.h5 tokenizer.pickle config.pickle
python 3_tf_analise_sentimento.py
```
